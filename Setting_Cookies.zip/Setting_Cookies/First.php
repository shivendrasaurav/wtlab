<?php

    $cookie_name = "TimeStamp";
    $cookie_value = date("h:i:s-d/m/y");
    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

?>

<html>
    <head>
        <title>Setting Cookie</title>
        <link href="https://fluentdesignforweb.github.io/fluent.css" type="text/css" rel="stylesheet" />
    </head>
    <body class="page_container primary_inverted">

        <br /><br />
        <br /><br />
        <h1>Set Cookie</h1>
        <br /><br />


        <form action="./Cookie.php">

            <button class="small primary_red">Click To Set Cookie</button>

        </form>

    </body>
</html>
