<?php

?>


<html>
    <head>
        <title>Getting Cookie</title>
        <link href="https://fluentdesignforweb.github.io/fluent.css" type="text/css" rel="stylesheet" />
    </head>
    <body class="page_container primary_inverted">

        <br /><br />
        <br /><br />
        <h1>Get Cookie</h1>
        <br /><br />

        <?php

            if(count($_COOKIE) > 0) {
                echo "<p>Last Cookie was stored at : " . $_COOKIE["TimeStamp"] . "</p>";
                echo "<p>Current Time : " . date("h:i:s-d/m/y") . "</p>";
            } 
            else {
                echo "<p>No Cookies stored till now</p>";
            }

        ?>

        <br /><br />
        <br /><br />
        <a href="./First.php">Go Back</a>

    </body>
</html>
